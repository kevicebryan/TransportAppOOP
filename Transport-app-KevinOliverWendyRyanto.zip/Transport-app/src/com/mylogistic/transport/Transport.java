package com.mylogistic.transport;

public interface Transport {
	void deliver();

	String toString(int transportID);
}
